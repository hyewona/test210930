package board;

public class Board_SuggestBean {
	private String b_s_id;
	private String b_s_name;
	public String getB_s_id() {
		return b_s_id;
	}
	public void setB_s_id(String b_s_id) {
		this.b_s_id = b_s_id;
	}
	public String getB_s_name() {
		return b_s_name;
	}
	public void setB_s_name(String b_s_name) {
		this.b_s_name = b_s_name;
	}
}
