package board;

public class Board_AnswerBean {
	private int b_a_id;
	private int b_a_ref;
	private String b_a_name;
	private String b_a_content;
	private String b_a_hidden;
	private int b_a_level;
	private String b_a_name_hidden;
	public String getB_a_name_hidden() {
		return b_a_name_hidden;
	}
	public void setB_a_name_hidden(String b_a_name_hidden) {
		this.b_a_name_hidden = b_a_name_hidden;
	}
	public int getB_a_level() {
		return b_a_level;
	}
	public void setB_a_level(int b_a_level) {
		this.b_a_level = b_a_level;
	}
	public String getB_a_hidden() {
		return b_a_hidden;
	}
	public void setB_a_hidden(String b_a_hidden) {
		this.b_a_hidden = b_a_hidden;
	}
	public int getB_a_id() {
		return b_a_id;
	}
	public void setB_a_id(int b_a_id) {
		this.b_a_id = b_a_id;
	}
	public int getB_a_ref() {
		return b_a_ref;
	}
	public void setB_a_ref(int b_a_ref) {
		this.b_a_ref = b_a_ref;
	}
	public String getB_a_name() {
		return b_a_name;
	}
	public void setB_a_name(String b_a_name) {
		this.b_a_name = b_a_name;
	}
	public String getB_a_content() {
		return b_a_content;
	}
	public void setB_a_content(String b_a_content) {
		this.b_a_content = b_a_content;
	}
	
}
